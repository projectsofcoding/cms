
import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import EmailList from './EmailList';
import Header from './Header';
import Mail from './Mail';
import Sidebar from './Sidebar';
import './App.css'



const App = () => {
  return (
    <Router>
  <div className="app">
    <Header />


    <div className="app__body" >
   <Sidebar />


   <Switch>
     <Route path="/mail">
       <Mail />
     </Route>
     <Route path="/">
       <EmailList />
       </Route>

   </Switch>

  
   </div>

  </div>
  </Router>
  );
}

export default App;
