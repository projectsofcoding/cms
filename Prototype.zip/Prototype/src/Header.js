import React from 'react'
import "./Header.css";
import MenuIcon from '@material-ui/icons/Menu';
import { Avatar, IconButton } from '@material-ui/core';
import SearchIcon from '@material-ui/icons/Search';
import { ArrowDropDown } from '@material-ui/icons';
import NotificationsIcon from '@material-ui/icons/Notifications';

import HelpIcon from '@material-ui/icons/Help';

export default function Header() {
    return (
        <div className="header">
            <div className ="header__left">
           <IconButton>
            <MenuIcon />
            </IconButton>
            <img src="https://www.nicepng.com/png/full/90-903914_e-mail-png-hd-round-email-icon-png.png" alt=""/>
            </div>
            <div className="header__middle">
            < SearchIcon />
            <input placeholder="Search null" type="text" />
            <ArrowDropDown className="header__inputCaret" />
            
            </div>
            <div className="header__right">
                <IconButton>
                 <HelpIcon />
                 </IconButton>
                <IconButton>
                <NotificationsIcon />
                </IconButton>
                <Avatar/>

            </div>
            
        </div>
    );
}